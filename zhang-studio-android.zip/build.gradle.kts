plugins {
    // AGP 8.10.0 + KGP 2.2.0 + Gradle 8.11.1 (13 Nov 2026): CI run #7 proved
    // AGP 8.2.2 is rejected by androidx.activity 1.13.0 / core 1.18.0
    // (checkDebugAarMetadata: "requires Android Gradle plugin 8.9.1 or
    // higher"), and API level 36 itself requires AGP >= 8.9.1 per Android
    // docs. AGP 8.10 needs Gradle >= 8.11.1; KGP 2.2.0 needs AGP >= 8.10
    // and reads the Kotlin 2.2 metadata in the new androidx libs.
    id("com.android.application") version "8.10.0" apply false
    id("org.jetbrains.kotlin.android") version "2.2.0" apply false
}
