package com.zhangstudio.app

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.media3.common.util.UnstableApi
import java.io.File
import java.io.FileInputStream
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Zhang Studio v0.6.2 — seven screens over the studio photo background:
 * 1. Login: Gemini API Key, entered once and remembered. A "Key သွားယူရန်"
 *    link opens the AI Studio key page so new users can get a key.
 * 2. Menu: all six features, all working now.
 * 3. Work (modes 1-2): pick a video -> Gemini SRT -> burn on the phone CPU
 *    (subtitle mode) or SRT alone (SRT mode). Finished files wait for the
 *    separate download button — nothing is saved to Downloads by itself.
 * 4. TTS (mode 3): type text -> AI voice reads it aloud (2 voices + speed
 *    slider + pitch slider) -> MP3 + SRT on demand. Server: POST /api/tts.
 * 5. Voiceover (mode 4): pick a video -> server transcribes/translates it,
 *    narrates it in Myanmar, and muxes the voice into the video -> finished
 *    MP4 + SRT on demand. Server: POST /api/voiceover (v16+).
 * 6. Timing (mode 5): pick a video + an SRT file -> shift subtitle timing
 *    (-10s..+10s) -> burn on the phone CPU, or save the shifted SRT alone.
 * 7. Prompt-video (mode 6): type a prompt -> 3-scene video with Myanmar
 *    narration + subtitles, on demand. Server: POST /api/prompt-video.
 *
 * Server jobs are polled (async), so slow connections never hit a single
 * long request that times out. A sync (v13) transcribe server still works.
 * All errors surface as status text — the app never crashes on bad input.
 * Rotating the phone during a burn cancels the export.
 */
@OptIn(UnstableApi::class)
class MainActivity : ComponentActivity() {

    private val modeSubtitle = 1
    private val modeSrt = 2
    private val modeTts = 3
    private val modeVoiceover = 4
    private val modeTiming = 5
    private val modePromptVideo = 6
    private var mode = modeSubtitle

    private var videoUri: Uri? = null
    private var voVideoUri: Uri? = null
    private var timingVideoUri: Uri? = null
    private var timingCues: List<SubtitleCue> = emptyList()
    private var timingShiftUs: Long = 0L
    private var timingBusy: Boolean = false
    private var burner: SubtitleBurner? = null
    private var timingBurner: SubtitleBurner? = null
    private var apiKey: String = ""

    // Two real Myanmar edge-tts voices (Nilar = female, Thiha = male);
    // pitch is a shared slider, not fixed presets (v0.6.2).
    private data class VoiceOption(val label: String, val voice: String)
    private val voiceOptions = listOf(
        VoiceOption("မိန်းကလေး အသံ", TtsClient.VOICE_NILAR),
        VoiceOption("ယောက်ျားလေး အသံ", TtsClient.VOICE_THIHA)
    )
    private var selectedVoiceIndex = 0
    private val voiceOptionButtons = mutableListOf<Pair<Button, Int>>()
    private var voicePitch: Int = 0
    private val pitchLabels = mutableListOf<TextView>()
    private val pitchBars = mutableListOf<SeekBar>()
    private var ttsRate: Int = 0

    private val prefs by lazy { getSharedPreferences("zhang_studio", MODE_PRIVATE) }

    private lateinit var loginScreen: View
    private lateinit var menuScreen: View
    private lateinit var workScreen: View
    private lateinit var ttsScreen: View
    private lateinit var voiceoverScreen: View
    private lateinit var timingScreen: View
    private lateinit var promptVideoScreen: View
    private lateinit var keyField: EditText
    private lateinit var loginStatus: TextView
    private lateinit var workTitle: TextView
    private lateinit var pickVideoButton: Button
    private lateinit var videoLabel: TextView
    private lateinit var makeButton: Button
    private lateinit var progressBar: ProgressBar
    private lateinit var statusText: TextView
    private lateinit var workDownloadButton: Button
    private var workLastOutput: File? = null
    private var workLastSrt: String? = null
    private lateinit var ttsTextField: EditText
    private lateinit var ttsRateLabel: TextView
    private lateinit var ttsMakeButton: Button
    private lateinit var ttsProgressBar: ProgressBar
    private lateinit var ttsStatusText: TextView
    private lateinit var ttsDownloadButton: Button
    private var ttsLastAudio: ByteArray? = null
    private var ttsLastSrt: String? = null
    private lateinit var voPickButton: Button
    private lateinit var voVideoLabel: TextView
    private lateinit var voMakeButton: Button
    private lateinit var voProgressBar: ProgressBar
    private lateinit var voStatusText: TextView
    private lateinit var voDownloadButton: Button
    private var voLastTmp: File? = null
    private var voLastVideoUrl: String? = null
    private var voLastSrt: String? = null
    private lateinit var timingPickVideoButton: Button
    private lateinit var timingVideoLabel: TextView
    private lateinit var timingPickSrtButton: Button
    private lateinit var timingSrtLabel: TextView
    private lateinit var timingShiftLabel: TextView
    private lateinit var timingInfoText: TextView
    private lateinit var timingBurnButton: Button
    private lateinit var timingSaveSrtButton: Button
    private lateinit var timingProgressBar: ProgressBar
    private lateinit var timingStatusText: TextView
    private lateinit var timingDownloadButton: Button
    private var timingLastOutput: File? = null
    private lateinit var pvTextField: EditText
    private lateinit var pvMakeButton: Button
    private lateinit var pvProgressBar: ProgressBar
    private lateinit var pvStatusText: TextView
    private lateinit var pvDownloadButton: Button
    private var pvLastTmp: File? = null
    private var pvLastVideoUrl: String? = null
    private var pvLastSrt: String? = null

    private val pickVideoLauncher =
        registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
            if (uri != null) {
                videoUri = uri
                videoLabel.text = "Video: ${uri.lastPathSegment ?: uri}"
                updateMakeEnabled()
            }
        }

    private val pickVoVideoLauncher =
        registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
            if (uri != null) {
                voVideoUri = uri
                voVideoLabel.text = "Video: ${uri.lastPathSegment ?: uri}"
                voMakeButton.isEnabled = true
            }
        }

    private val pickTimingVideoLauncher =
        registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
            if (uri != null) {
                timingVideoUri = uri
                timingVideoLabel.text = "Video: ${uri.lastPathSegment ?: uri}"
                updateTimingEnabled()
            }
        }

    private val pickSrtLauncher =
        registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
            if (uri == null) return@registerForActivityResult
            try {
                val text = contentResolver.openInputStream(uri)?.use {
                    it.readBytes().toString(Charsets.UTF_8)
                } ?: ""
                val cues = SrtParser.parse(text)
                if (cues.isEmpty()) {
                    timingCues = emptyList()
                    timingSrtLabel.text = "SRT ဖိုင်မှာ စာတန်း မတွေ့ဘူး။"
                } else {
                    timingCues = cues
                    timingSrtLabel.text = "SRT: စာတန်း ${cues.size} ပိုင်း"
                }
            } catch (e: Exception) {
                timingCues = emptyList()
                timingSrtLabel.text = "SRT ဖတ်လို့ မရဘူး။"
            }
            updateTimingInfo()
            updateTimingEnabled()
        }

    private val burnCallback = object : SubtitleBurner.Callback {
        override fun onProgress(percent: Int) {
            progressBar.progress = percent
            setStatus("စာတန်းထည့်နေတယ်… $percent%")
        }

        override fun onCompleted(outputPath: String) {
            // v0.6.2: no auto-download — the finished file waits until
            // the user taps the separate download button.
            workLastOutput = File(outputPath)
            workLastSrt = null
            runOnUiThread {
                setBusy(false)
                progressBar.progress = 100
                workDownloadButton.text = "Video ဒေါင်းလုဒ်လုပ်ရန်"
                workDownloadButton.visibility = View.VISIBLE
                setStatus("ပြီးပြီ — ဒေါင်းလုဒ်လုပ်ရန် အောက်က ခလုတ်ကို နှိပ်ပါ။")
            }
        }

        override fun onError(message: String) {
            setBusy(false)
            setStatus("အမှား: $message")
        }
    }

    private val timingBurnCallback = object : SubtitleBurner.Callback {
        override fun onProgress(percent: Int) {
            timingProgressBar.progress = percent
            timingStatusText.text = "စာတန်းထည့်နေတယ်… $percent%"
        }

        override fun onCompleted(outputPath: String) {
            // v0.6.2: no auto-download — the finished file waits until
            // the user taps the separate download button.
            timingLastOutput = File(outputPath)
            runOnUiThread {
                timingBusy = false
                updateTimingEnabled()
                timingProgressBar.progress = 100
                timingDownloadButton.visibility = View.VISIBLE
                timingStatusText.text = "ပြီးပြီ — ဒေါင်းလုဒ်လုပ်ရန် အောက်က ခလုတ်ကို နှိပ်ပါ။"
            }
        }

        override fun onError(message: String) {
            timingBusy = false
            updateTimingEnabled()
            timingStatusText.text = "အမှား: $message"
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        apiKey = prefs.getString("gemini_api_key", "").orEmpty()

        val root = FrameLayout(this).apply {
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
            setBackgroundColor(Color.rgb(17, 20, 24))
        }

        // Studio photo background + dark overlay for readable text.
        try {
            val bmp = assets.open("studio_bg.jpg").use { BitmapFactory.decodeStream(it) }
            if (bmp != null) {
                root.addView(ImageView(this).apply {
                    setImageBitmap(bmp)
                    scaleType = ImageView.ScaleType.CENTER_CROP
                    layoutParams = FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                    )
                })
            }
        } catch (e: Exception) {
            // No background image: the dark solid color stays.
        }
        root.addView(View(this).apply {
            setBackgroundColor(Color.argb(110, 0, 0, 0))
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        })

        loginScreen = buildLoginScreen()
        menuScreen = buildMenuScreen()
        workScreen = buildWorkScreen()
        ttsScreen = buildTtsScreen()
        voiceoverScreen = buildVoiceoverScreen()
        timingScreen = buildTimingScreen()
        promptVideoScreen = buildPromptVideoScreen()
        root.addView(loginScreen)
        root.addView(menuScreen)
        root.addView(workScreen)
        root.addView(ttsScreen)
        root.addView(voiceoverScreen)
        root.addView(timingScreen)
        root.addView(promptVideoScreen)
        setContentView(root)

        if (apiKey.isBlank()) showScreen(loginScreen) else showScreen(menuScreen)
    }

    override fun onDestroy() {
        burner?.cancel()
        burner = null
        timingBurner?.cancel()
        timingBurner = null
        super.onDestroy()
    }

    // ---------- screens ----------

    private fun showScreen(screen: View) {
        loginScreen.visibility = if (screen === loginScreen) View.VISIBLE else View.GONE
        menuScreen.visibility = if (screen === menuScreen) View.VISIBLE else View.GONE
        workScreen.visibility = if (screen === workScreen) View.VISIBLE else View.GONE
        ttsScreen.visibility = if (screen === ttsScreen) View.VISIBLE else View.GONE
        voiceoverScreen.visibility =
            if (screen === voiceoverScreen) View.VISIBLE else View.GONE
        timingScreen.visibility = if (screen === timingScreen) View.VISIBLE else View.GONE
        promptVideoScreen.visibility =
            if (screen === promptVideoScreen) View.VISIBLE else View.GONE
    }

    private fun screenColumn(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        val pad = dp(24)
        setPadding(pad, dp(48), pad, pad)
        layoutParams = ViewGroup.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
    }

    private fun wrapScroll(column: LinearLayout): ScrollView = ScrollView(this).apply {
        layoutParams = FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT
        )
        addView(column)
    }

    private fun buildLoginScreen(): View {
        val col = screenColumn()
        col.addView(titleText("ZHANG Studio", 32f))
        col.addView(titleText("မှ ကြိုဆိုပါတယ်", 26f))

        val banner = TextView(this).apply {
            text = "Gemini API Key ထည့်ပြီး\nစတင် အသုံးပြုနိုင်ပါပြီ"
            textSize = 18f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            background = pillBg(Color.rgb(13, 84, 96), Color.rgb(72, 199, 214), 2)
            setPadding(dp(20), dp(20), dp(20), dp(20))
        }
        col.addView(banner, rowParams(dp(40)))

        keyField = EditText(this).apply {
            hint = "API Key"
            textSize = 18f
            setTextColor(Color.BLACK)
            setHintTextColor(Color.rgb(130, 130, 130))
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
            setSingleLine(true)
            background = pillBg(Color.WHITE, null, 0)
            setPadding(dp(22), dp(14), dp(22), dp(14))
            if (apiKey.isNotBlank()) setText(apiKey)
        }
        col.addView(keyField, rowParams(dp(24)))

        val loginButton = pillButton("Login", Color.rgb(35, 35, 35), Color.WHITE, null)
        loginButton.setOnClickListener { onLoginClicked() }
        col.addView(loginButton, rowParams(dp(16)))

        loginStatus = TextView(this).apply {
            textSize = 15f
            setTextColor(Color.rgb(255, 213, 74))
            gravity = Gravity.CENTER
        }
        col.addView(loginStatus, rowParams(dp(12)))

        // "Go get a Key" link: new users who don't know what a key is can
        // tap it and land straight on the free AI Studio key page.
        val keyLink = TextView(this).apply {
            text = "🔑 Key သွားယူရန်"
            textSize = 17f
            setTextColor(Color.rgb(255, 213, 74))
            gravity = Gravity.CENTER
            paint.isUnderlineText = true
            setPadding(dp(12), dp(12), dp(12), dp(12))
        }
        keyLink.setOnClickListener {
            try {
                startActivity(
                    Intent(
                        Intent.ACTION_VIEW,
                        Uri.parse("https://aistudio.google.com/apikey")
                    )
                )
            } catch (e: Exception) {
                loginStatus.text = "Link ဖွင့်လို့ မရဘူး။"
            }
        }
        col.addView(keyLink, rowParams(dp(8)))

        col.addView(hintText("Key ကို aistudio.google.com/apikey မှာ အခမဲ့ ရယူနိုင်ပါတယ်"),
            rowParams(dp(12)))
        return wrapScroll(col)
    }

    private fun buildMenuScreen(): View {
        val col = screenColumn()
        col.addView(titleText("ZHANG Studio", 30f))
        col.addView(titleText("လုပ်ဆောင်ချက်များ ရွေးချယ်ပါ", 20f))

        val green = Color.rgb(30, 107, 74)
        val greenStroke = Color.rgb(76, 175, 125)
        val items = listOf(
            "SRT သီးသန့်ထုတ်ရန်" to modeSrt,
            "Video ကို မြန်မာစာတန်းထိုးပေးရန်" to modeSubtitle,
            "ရေးထားသောစာများကို\nAI အသံဖြင့် ဖတ်ပြရန်" to modeTts,
            "Video များကို မြန်မာအသံဖြင့်\nပြောပြပေးရန်" to modeVoiceover,
            "SRT နှင့် Video တွဲရန် နှင့်\nစာသား အတိုအရှည် စိတ်ကြိုက်ချိန်ရန်" to modeTiming,
            "Prompt ရေးပြီး Video ထုတ်ရန်" to modePromptVideo
        )
        for ((label, targetMode) in items) {
            val b = pillButton(label, Color.WHITE, green, greenStroke)
            b.setOnClickListener {
                when (targetMode) {
                    modeSrt, modeSubtitle -> openWork(targetMode)
                    modeTts -> showScreen(ttsScreen)
                    modeVoiceover -> showScreen(voiceoverScreen)
                    modeTiming -> showScreen(timingScreen)
                    modePromptVideo -> showScreen(promptVideoScreen)
                }
            }
            col.addView(b, rowParams(dp(18)))
        }

        val changeKey = TextView(this).apply {
            text = "API Key ပြောင်းရန်"
            textSize = 15f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(dp(12), dp(12), dp(12), dp(12))
        }
        changeKey.setOnClickListener {
            keyField.setText(apiKey)
            loginStatus.text = ""
            showScreen(loginScreen)
        }
        col.addView(changeKey, rowParams(dp(18)))
        return wrapScroll(col)
    }

    private fun buildWorkScreen(): View {
        val col = screenColumn()
        workTitle = titleText("", 22f)
        col.addView(workTitle)

        pickVideoButton = pillButton("Video ရွေးပါ", Color.WHITE, Color.BLACK, null)
        pickVideoButton.setOnClickListener { pickVideoLauncher.launch("video/*") }
        col.addView(pickVideoButton, rowParams(dp(24)))

        videoLabel = TextView(this).apply {
            text = "Video မရွေးရသေးဘူး"
            textSize = 16f
            setTextColor(Color.WHITE)
        }
        col.addView(videoLabel, rowParams(dp(12)))

        makeButton = pillButton("", Color.rgb(13, 84, 96), Color.WHITE, Color.rgb(72, 199, 214))
        makeButton.isEnabled = false
        makeButton.setOnClickListener { onMakeClicked() }
        col.addView(makeButton, rowParams(dp(12)))

        progressBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            progress = 0
        }
        col.addView(progressBar, rowParams(dp(16)))

        statusText = TextView(this).apply {
            text = "Video ရွေးပါ။"
            textSize = 16f
            setTextColor(Color.WHITE)
        }
        col.addView(statusText, rowParams(dp(8)))

        workDownloadButton = pillButton("Video ဒေါင်းလုဒ်လုပ်ရန်", Color.WHITE, Color.BLACK, null)
        workDownloadButton.visibility = View.GONE
        workDownloadButton.setOnClickListener { onWorkDownloadClicked() }
        col.addView(workDownloadButton, rowParams(dp(12)))

        col.addView(backLink(), rowParams(dp(16)))
        return wrapScroll(col)
    }

    private fun buildTtsScreen(): View {
        val col = screenColumn()
        col.addView(titleText("စာကို AI အသံဖြင့် ဖတ်ပြရန်", 22f))

        ttsTextField = EditText(this).apply {
            hint = "ဖတ်ပြစေချင်တဲ့ မြန်မာစာသား ဒီမှာ ရိုက်ထည့်ပါ..."
            textSize = 17f
            setTextColor(Color.BLACK)
            setHintTextColor(Color.rgb(130, 130, 130))
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
            minLines = 6
            gravity = Gravity.TOP
            background = pillBg(Color.WHITE, null, 0)
            setPadding(dp(22), dp(14), dp(22), dp(14))
        }
        col.addView(ttsTextField, rowParams(dp(24)))

        col.addView(sectionLabel("အသံ ရွေးပါ"), rowParams(dp(20)))
        col.addView(buildVoicePicker(), rowParams(dp(8)))

        ttsRateLabel = TextView(this).apply {
            text = "အမြန်နှုန်း: ပုံမှန်"
            textSize = 16f
            setTextColor(Color.WHITE)
        }
        col.addView(ttsRateLabel, rowParams(dp(20)))
        val rateBar = SeekBar(this).apply { max = 20; progress = 10 }
        rateBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                ttsRate = (progress - 10) * 5
                ttsRateLabel.text = when {
                    ttsRate == 0 -> "အမြန်နှုန်း: ပုံမှန်"
                    ttsRate > 0 -> "အမြန်နှုန်း: +$ttsRate% မြန်"
                    else -> "အမြန်နှုန်း: $ttsRate% နှေး"
                }
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
        col.addView(rateBar, rowParams(dp(4)))

        ttsMakeButton = pillButton(
            "အသံထုတ်မယ်", Color.rgb(13, 84, 96), Color.WHITE, Color.rgb(72, 199, 214)
        )
        ttsMakeButton.setOnClickListener { onTtsClicked() }
        col.addView(ttsMakeButton, rowParams(dp(16)))

        ttsProgressBar =
            ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
                max = 100
                progress = 0
            }
        col.addView(ttsProgressBar, rowParams(dp(16)))

        ttsStatusText = TextView(this).apply {
            text = "စာသား ရိုက်ထည့်ပြီး အသံထုတ်ပါ။ (စာသား အရှည် ၁၅၀၀၀ လုံးထိ ရတယ်)"
            textSize = 16f
            setTextColor(Color.WHITE)
        }
        col.addView(ttsStatusText, rowParams(dp(8)))

        ttsDownloadButton = pillButton("အသံ + SRT ဒေါင်းလုဒ်လုပ်ရန်", Color.WHITE, Color.BLACK, null)
        ttsDownloadButton.visibility = View.GONE
        ttsDownloadButton.setOnClickListener { onTtsDownloadClicked() }
        col.addView(ttsDownloadButton, rowParams(dp(12)))

        col.addView(backLink(), rowParams(dp(16)))
        return wrapScroll(col)
    }

    private fun buildVoiceoverScreen(): View {
        val col = screenColumn()
        col.addView(titleText("Video ကို မြန်မာအသံဖြင့် ပြောပြရန်", 22f))

        col.addView(
            hintText("Video ရဲ့ အသံကို မြန်မာလို ပြောင်းပြီး AI အသံကို Video ထဲမှာ ထည့်ပေးမယ်။ ပြီးရင် ဒေါင်းလုဒ်ခလုတ် နှိပ်မှ Downloads ထဲ သိမ်းမယ်။"),
            rowParams(dp(16))
        )

        voPickButton = pillButton("Video ရွေးပါ", Color.WHITE, Color.BLACK, null)
        voPickButton.setOnClickListener { pickVoVideoLauncher.launch("video/*") }
        col.addView(voPickButton, rowParams(dp(20)))

        voVideoLabel = TextView(this).apply {
            text = "Video မရွေးရသေးဘူး"
            textSize = 16f
            setTextColor(Color.WHITE)
        }
        col.addView(voVideoLabel, rowParams(dp(12)))

        col.addView(sectionLabel("အသံ ရွေးပါ"), rowParams(dp(16)))
        col.addView(buildVoicePicker(), rowParams(dp(8)))

        voMakeButton = pillButton(
            "မြန်မာအသံထုတ်မယ်", Color.rgb(13, 84, 96), Color.WHITE, Color.rgb(72, 199, 214)
        )
        voMakeButton.isEnabled = false
        voMakeButton.setOnClickListener { onVoiceoverClicked() }
        col.addView(voMakeButton, rowParams(dp(16)))

        voProgressBar =
            ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
                max = 100
                progress = 0
            }
        col.addView(voProgressBar, rowParams(dp(16)))

        voStatusText = TextView(this).apply {
            text = "Video ရွေးပါ။"
            textSize = 16f
            setTextColor(Color.WHITE)
        }
        col.addView(voStatusText, rowParams(dp(8)))

        voDownloadButton = pillButton(
            "Video ဒေါင်းလုဒ်လုပ်ရန်", Color.WHITE, Color.BLACK, null
        )
        voDownloadButton.visibility = View.GONE
        voDownloadButton.setOnClickListener { onVoDownloadClicked() }
        col.addView(voDownloadButton, rowParams(dp(12)))

        col.addView(backLink(), rowParams(dp(16)))
        return wrapScroll(col)
    }

    private fun buildPromptVideoScreen(): View {
        val col = screenColumn()
        col.addView(titleText("Prompt ရေးပြီး Video ထုတ်ရန်", 22f))

        col.addView(
            hintText("စိတ်ကူးကို ရိုက်ထည့်ရုံနဲ့ 3 ပိုင်းပါ Video (တစ်ပိုင်း 10 စက္ကန့်) ထုတ်ပေးမယ် — ပုံ + လှုပ်ရှားမှု + မြန်မာအသံ + မြန်မာစာတန်း ပါမယ်။ အချိန် အနည်းငယ် ကြာနိုင်တယ်။"),
            rowParams(dp(16))
        )

        pvTextField = EditText(this).apply {
            hint = "ဥပမာ — ရွာက ကြောင်လေးတစ်ကောင် ဈေးထဲမှာ ငါးခိုးစားတဲ့ ဇာတ်လမ်း"
            textSize = 17f
            setTextColor(Color.BLACK)
            setHintTextColor(Color.rgb(130, 130, 130))
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
            minLines = 4
            gravity = Gravity.TOP
            background = pillBg(Color.WHITE, null, 0)
            setPadding(dp(22), dp(14), dp(22), dp(14))
        }
        col.addView(pvTextField, rowParams(dp(20)))

        col.addView(sectionLabel("အသံ ရွေးပါ"), rowParams(dp(16)))
        col.addView(buildVoicePicker(), rowParams(dp(8)))

        pvMakeButton = pillButton(
            "Video ထုတ်မယ်", Color.rgb(13, 84, 96), Color.WHITE, Color.rgb(72, 199, 214)
        )
        pvMakeButton.setOnClickListener { onPromptVideoClicked() }
        col.addView(pvMakeButton, rowParams(dp(16)))

        pvProgressBar =
            ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
                max = 100
                progress = 0
            }
        col.addView(pvProgressBar, rowParams(dp(16)))

        pvStatusText = TextView(this).apply {
            text = "Prompt ရိုက်ထည့်ပြီး Video ထုတ်ပါ။"
            textSize = 16f
            setTextColor(Color.WHITE)
        }
        col.addView(pvStatusText, rowParams(dp(8)))

        pvDownloadButton = pillButton(
            "Video ဒေါင်းလုဒ်လုပ်ရန်", Color.WHITE, Color.BLACK, null
        )
        pvDownloadButton.visibility = View.GONE
        pvDownloadButton.setOnClickListener { onPvDownloadClicked() }
        col.addView(pvDownloadButton, rowParams(dp(12)))

        col.addView(backLink(), rowParams(dp(16)))
        return wrapScroll(col)
    }

    private fun buildTimingScreen(): View {
        val col = screenColumn()
        col.addView(titleText("SRT + Video တွဲရန် / အချိန်ချိန်ရန်", 22f))

        col.addView(
            hintText("SRT ဖိုင်ရွေးပြီး အချိန်ကို ရွှေ့ပါ — Video နဲ့ စာတန်း ကိုက်အောင် ချိန်နိုင်တယ်။"),
            rowParams(dp(16))
        )

        timingPickVideoButton = pillButton("Video ရွေးပါ", Color.WHITE, Color.BLACK, null)
        timingPickVideoButton.setOnClickListener { pickTimingVideoLauncher.launch("video/*") }
        col.addView(timingPickVideoButton, rowParams(dp(20)))

        timingVideoLabel = TextView(this).apply {
            text = "Video မရွေးရသေးဘူး"
            textSize = 16f
            setTextColor(Color.WHITE)
        }
        col.addView(timingVideoLabel, rowParams(dp(12)))

        timingPickSrtButton = pillButton("SRT ဖိုင်ရွေးပါ", Color.WHITE, Color.BLACK, null)
        timingPickSrtButton.setOnClickListener { pickSrtLauncher.launch("*/*") }
        col.addView(timingPickSrtButton, rowParams(dp(12)))

        timingSrtLabel = TextView(this).apply {
            text = "SRT မရွေးရသေးဘူး"
            textSize = 16f
            setTextColor(Color.WHITE)
        }
        col.addView(timingSrtLabel, rowParams(dp(12)))

        timingShiftLabel = TextView(this).apply {
            text = "စာတန်း အချိန်: ပုံမှန် (မရွှေ့ဘူး)"
            textSize = 16f
            setTextColor(Color.WHITE)
        }
        col.addView(timingShiftLabel, rowParams(dp(20)))
        val shiftBar = SeekBar(this).apply { max = 40; progress = 20 }
        shiftBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                val seconds = (progress - 20) * 0.5
                timingShiftUs = (seconds * 1_000_000).toLong()
                timingShiftLabel.text = when {
                    seconds == 0.0 -> "စာတန်း အချိန်: ပုံမှန် (မရွှေ့ဘူး)"
                    seconds > 0 -> "စာတန်း အချိန်: +${fmtSeconds(seconds)} စက္ကန့် နောက်ကျ"
                    else -> "စာတန်း အချိန်: ${fmtSeconds(seconds)} စက္ကန့် စော"
                }
                updateTimingInfo()
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
        col.addView(shiftBar, rowParams(dp(4)))

        timingInfoText = TextView(this).apply {
            textSize = 15f
            setTextColor(Color.rgb(255, 213, 74))
        }
        col.addView(timingInfoText, rowParams(dp(8)))

        timingBurnButton = pillButton(
            "Video လုပ်မယ်", Color.rgb(13, 84, 96), Color.WHITE, Color.rgb(72, 199, 214)
        )
        timingBurnButton.isEnabled = false
        timingBurnButton.setOnClickListener { onTimingBurnClicked() }
        col.addView(timingBurnButton, rowParams(dp(12)))

        timingSaveSrtButton = pillButton("SRT သီးသန့်သိမ်းမယ်", Color.WHITE, Color.BLACK, null)
        timingSaveSrtButton.isEnabled = false
        timingSaveSrtButton.setOnClickListener { onTimingSaveSrtClicked() }
        col.addView(timingSaveSrtButton, rowParams(dp(12)))

        timingProgressBar =
            ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
                max = 100
                progress = 0
            }
        col.addView(timingProgressBar, rowParams(dp(16)))

        timingStatusText = TextView(this).apply {
            text = "Video နဲ့ SRT ရွေးပါ။"
            textSize = 16f
            setTextColor(Color.WHITE)
        }
        col.addView(timingStatusText, rowParams(dp(8)))

        timingDownloadButton = pillButton("Video ဒေါင်းလုဒ်လုပ်ရန်", Color.WHITE, Color.BLACK, null)
        timingDownloadButton.visibility = View.GONE
        timingDownloadButton.setOnClickListener { onTimingDownloadClicked() }
        col.addView(timingDownloadButton, rowParams(dp(12)))

        col.addView(backLink(), rowParams(dp(16)))
        return wrapScroll(col)
    }

    /** The 4 voice-option buttons; shared selection state across screens. */
    private fun buildVoicePicker(): LinearLayout {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        for ((index, option) in voiceOptions.withIndex()) {
            val b = pillButton(option.label, Color.WHITE, Color.BLACK, null)
            b.textSize = 16f
            b.setOnClickListener {
                selectedVoiceIndex = index
                refreshVoiceButtons()
            }
            voiceOptionButtons.add(b to index)
            box.addView(b, rowParams(if (index == 0) 0 else dp(10)))
        }
        refreshVoiceButtons()
        // Shared pitch slider (-50..+50 in steps of 5, the range the
        // server clamps to). Every picker on every screen stays in sync.
        val pitchLabel = TextView(this).apply {
            textSize = 16f
            setTextColor(Color.WHITE)
        }
        pitchLabels.add(pitchLabel)
        box.addView(pitchLabel, rowParams(dp(16)))
        val pitchBar = SeekBar(this).apply { max = 20; progress = 10 + voicePitch / 5 }
        pitchBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                voicePitch = (progress - 10) * 5
                refreshPitchControls()
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
        pitchBars.add(pitchBar)
        box.addView(pitchBar, rowParams(dp(4)))
        refreshPitchControls()
        return box
    }

    private fun refreshPitchControls() {
        val label = when {
            voicePitch == 0 -> "အသံ အနိမ့်အမြင့်: ပုံမှန်"
            voicePitch > 0 -> "အသံ အနိမ့်အမြင့်: +$voicePitch မြင့်"
            else -> "အသံ အနိမ့်အမြင့်: $voicePitch နိမ့်"
        }
        for (tv in pitchLabels) tv.text = label
        for (bar in pitchBars) {
            val target = 10 + voicePitch / 5
            if (bar.progress != target) bar.progress = target
        }
    }

    private fun refreshVoiceButtons() {
        for ((button, index) in voiceOptionButtons) {
            val selected = index == selectedVoiceIndex
            button.background = pillBg(
                if (selected) Color.rgb(13, 84, 96) else Color.WHITE,
                if (selected) Color.rgb(72, 199, 214) else null,
                2
            )
            button.setTextColor(if (selected) Color.WHITE else Color.BLACK)
        }
    }

    private fun backLink(): TextView = TextView(this).apply {
        text = "← Menu သို့ ပြန်သွားမယ်"
        textSize = 15f
        setTextColor(Color.WHITE)
        gravity = Gravity.CENTER
        setPadding(dp(12), dp(12), dp(12), dp(12))
        setOnClickListener { showScreen(menuScreen) }
    }

    // ---------- actions ----------

    private fun onLoginClicked() {
        val key = keyField.text.toString().trim()
        if (key.isEmpty()) {
            loginStatus.text = "API Key ထည့်ပါ။"
            return
        }
        // Hide the keyboard: it used to stay open over the menu screen.
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager
        imm?.hideSoftInputFromWindow(keyField.windowToken, 0)
        apiKey = key
        prefs.edit().putString("gemini_api_key", key).apply()
        loginStatus.text = ""
        showScreen(menuScreen)
    }

    private fun openWork(targetMode: Int) {
        mode = targetMode
        if (mode == modeSrt) {
            workTitle.text = "SRT သီးသန့်ထုတ်ရန်"
            makeButton.text = "SRT ထုတ်မယ်"
        } else {
            workTitle.text = "Video ကို မြန်မာစာတန်းထိုးပေးရန်"
            makeButton.text = "စာတန်းထိုးထားသော Video လုပ်မယ်"
        }
        setStatus("Video ရွေးပါ။")
        progressBar.progress = 0
        updateMakeEnabled()
        showScreen(workScreen)
    }

    private fun onMakeClicked() {
        val video = videoUri ?: return
        setBusy(true)
        progressBar.progress = 0
        workDownloadButton.visibility = View.GONE
        workLastOutput = null
        workLastSrt = null
        setStatus("Video တင်နေတယ်…")
        Thread {
            try {
                val fileName = video.lastPathSegment ?: "video.mp4"
                val client = TranscribeClient(contentResolver)
                val srtText = when (val res = client.submit(video, fileName, apiKey)) {
                    is TranscribeClient.SubmitResult.Ready -> res.srt
                    is TranscribeClient.SubmitResult.Job -> {
                        postStatus("Gemini က အသံနားထောင်နေတယ်… (၁-၃ မိနစ် ကြာနိုင်တယ်)")
                        waitForJob(client, res.jobId)
                    }
                }
                val cues = SrtParser.parse(srtText)
                if (cues.isEmpty()) {
                    postError("ဒီ Video မှာ အသံမတွေ့ဘူး။")
                    return@Thread
                }
                if (mode == modeSrt) {
                    // v0.6.2: SRT waits for the download button too.
                    workLastSrt = srtText
                    runOnUiThread {
                        setBusy(false)
                        progressBar.progress = 100
                        workDownloadButton.text = "SRT ဒေါင်းလုဒ်လုပ်ရန်"
                        workDownloadButton.visibility = View.VISIBLE
                        setStatus("ပြီးပြီ — ဒေါင်းလုဒ်လုပ်ရန် အောက်က ခလုတ်ကို နှိပ်ပါ။")
                    }
                    return@Thread
                }
                // Transformer must start on the main thread.
                runOnUiThread {
                    if (isFinishing || isDestroyed) return@runOnUiThread
                    try {
                        val typeface = loadMyanmarTypeface()
                        val outputFile = newOutputFile()
                        val newBurner = SubtitleBurner(this)
                        burner = newBurner
                        setStatus("စာတန်းထည့်နေတယ်… 0%")
                        newBurner.start(video, cues, typeface, outputFile, burnCallback)
                    } catch (e: Exception) {
                        setBusy(false)
                        setStatus("အမှား: ${e.message ?: "unknown error"}")
                    }
                }
            } catch (e: Exception) {
                postError(e.message ?: "unknown error")
            }
        }.start()
    }

    private fun onTtsClicked() {
        val text = ttsTextField.text.toString().trim()
        if (text.isEmpty()) {
            ttsStatusText.text = "စာသား ရိုက်ထည့်ပါ။"
            return
        }
        val option = voiceOptions[selectedVoiceIndex]
        val rate = ttsRate
        val pitch = voicePitch
        ttsMakeButton.isEnabled = false
        ttsDownloadButton.visibility = View.GONE
        ttsLastAudio = null
        ttsLastSrt = null
        ttsProgressBar.isIndeterminate = true
        ttsStatusText.text = "အသံထုတ်နေတယ်…"
        Thread {
            try {
                val jobId = TtsClient().submit(text, option.voice, rate, pitch)
                runOnUiThread { ttsStatusText.text = "AI အသံဖတ်ပြနေတယ်…" }
                val state = pollUntilDone(TranscribeClient(contentResolver), jobId)
                val audioUrl = state.audioUrl
                    ?: throw IOException("Server က အသံဖိုင် ပြန်မပေးဘူး။")
                val audio = TtsClient().downloadAudio(audioUrl)
                // v0.6.2: keep the audio until the user taps download.
                ttsLastAudio = audio
                ttsLastSrt = state.srt?.takeIf { it.isNotBlank() }
                runOnUiThread {
                    ttsMakeButton.isEnabled = true
                    ttsProgressBar.isIndeterminate = false
                    ttsProgressBar.progress = 100
                    ttsDownloadButton.visibility = View.VISIBLE
                    ttsStatusText.text = "ပြီးပြီ — ဒေါင်းလုဒ်လုပ်ရန် အောက်က ခလုတ်ကို နှိပ်ပါ။"
                }
            } catch (e: Exception) {
                runOnUiThread {
                    ttsMakeButton.isEnabled = true
                    ttsProgressBar.isIndeterminate = false
                    ttsProgressBar.progress = 0
                    ttsStatusText.text = "အမှား: ${e.message ?: "unknown error"}"
                }
            }
        }.start()
    }

    private fun onVoiceoverClicked() {
        val video = voVideoUri ?: return
        val option = voiceOptions[selectedVoiceIndex]
        voPickButton.isEnabled = false
        voMakeButton.isEnabled = false
        voDownloadButton.visibility = View.GONE
        voProgressBar.isIndeterminate = true
        voStatusText.text = "Video တင်နေတယ်…"
        Thread {
            try {
                val fileName = video.lastPathSegment ?: "video.mp4"
                val client = TranscribeClient(contentResolver)
                val jobId = client.submitVoiceover(
                    video, fileName, apiKey, option.voice, 0, voicePitch
                )
                runOnUiThread {
                    voStatusText.text = "မြန်မာအသံ ထည့်နေတယ်… (၁-၃ မိနစ် ကြာနိုင်တယ်)"
                }
                val state = pollUntilDone(client, jobId)
                val videoUrl = state.videoUrl
                    ?: throw IOException("Server က Video ပြန်မပေးဘူး။")
                runOnUiThread { voStatusText.text = "Video ပြန်ယူနေတယ်…" }
                val tmp = File(cacheDir, "voiceover-${stamp()}.mp4")
                client.downloadToFile(videoUrl, tmp)
                runOnUiThread {
                    voPickButton.isEnabled = true
                    voMakeButton.isEnabled = true
                    voProgressBar.isIndeterminate = false
                    voProgressBar.progress = 100
                    voLastTmp = tmp
                    voLastVideoUrl = videoUrl
                    voLastSrt = state.srt
                    voDownloadButton.visibility = View.VISIBLE
                    voStatusText.text = "ပြီးပြီ — ဒေါင်းလုဒ်လုပ်ရန် အောက်က ခလုတ်ကို နှိပ်ပါ။"
                }
            } catch (e: Exception) {
                runOnUiThread {
                    voPickButton.isEnabled = true
                    voMakeButton.isEnabled = voVideoUri != null
                    voProgressBar.isIndeterminate = false
                    voProgressBar.progress = 0
                    voStatusText.text = "အမှား: ${e.message ?: "unknown error"}"
                }
            }
        }.start()
    }

    private fun onPromptVideoClicked() {
        val prompt = pvTextField.text.toString().trim()
        if (prompt.isEmpty()) {
            pvStatusText.text = "Prompt ရိုက်ထည့်ပါ။"
            return
        }
        val option = voiceOptions[selectedVoiceIndex]
        pvMakeButton.isEnabled = false
        pvDownloadButton.visibility = View.GONE
        pvProgressBar.isIndeterminate = true
        pvStatusText.text = "ဇာတ်လမ်း ရေးနေတယ်…"
        Thread {
            try {
                val jobId = TtsClient().submitPromptVideo(
                    prompt, apiKey, option.voice, 0, voicePitch
                )
                runOnUiThread {
                    pvStatusText.text = "ပုံထုတ် + အသံထည့် + Video ပေါင်းနေတယ်… (မိနစ် အနည်းငယ် ကြာနိုင်တယ်)"
                }
                val client = TranscribeClient(contentResolver)
                // Prompt-video assembles 3 scenes on the free server, so it
                // may take longer than a transcription: allow ~30 minutes.
                val state = pollUntilDone(client, jobId, maxWaits = 450)
                val videoUrl = state.videoUrl
                    ?: throw IOException("Server က Video ပြန်မပေးဘူး။")
                runOnUiThread { pvStatusText.text = "Video ပြန်ယူနေတယ်…" }
                val tmp = File(cacheDir, "prompt-video-${stamp()}.mp4")
                client.downloadToFile(videoUrl, tmp)
                runOnUiThread {
                    pvMakeButton.isEnabled = true
                    pvProgressBar.isIndeterminate = false
                    pvProgressBar.progress = 100
                    pvLastTmp = tmp
                    pvLastVideoUrl = videoUrl
                    pvLastSrt = state.srt
                    pvDownloadButton.visibility = View.VISIBLE
                    pvStatusText.text = "ပြီးပြီ — ဒေါင်းလုဒ်လုပ်ရန် အောက်က ခလုတ်ကို နှိပ်ပါ။"
                }
            } catch (e: Exception) {
                runOnUiThread {
                    pvMakeButton.isEnabled = true
                    pvProgressBar.isIndeterminate = false
                    pvProgressBar.progress = 0
                    pvStatusText.text = "အမှား: ${e.message ?: "unknown error"}"
                }
            }
        }.start()
    }

    // v0.6.2: finished files are saved to Downloads only when the user
    // taps the separate download button on each screen.
    private fun onWorkDownloadClicked() {
        val srt = workLastSrt
        val output = workLastOutput
        if (srt == null && output == null) return
        workDownloadButton.isEnabled = false
        setStatus("Downloads ထဲ သိမ်းနေတယ်…")
        Thread {
            try {
                val savedName = if (srt != null) {
                    saveSrtToDownloads(srt)
                } else {
                    copyToDownloads(output!!, "video/mp4")
                }
                runOnUiThread {
                    workDownloadButton.isEnabled = true
                    if (savedName != null) {
                        setStatus("ပြီးပြီ — Downloads ထဲ သိမ်းပြီးပြီ:\n$savedName")
                    } else {
                        setStatus("အမှား: သိမ်းလို့ မရဘူး။")
                    }
                }
            } catch (e: Exception) {
                runOnUiThread {
                    workDownloadButton.isEnabled = true
                    setStatus("အမှား: ${e.message ?: "unknown error"}")
                }
            }
        }.start()
    }

    private fun onTtsDownloadClicked() {
        val audio = ttsLastAudio ?: return
        ttsDownloadButton.isEnabled = false
        ttsStatusText.text = "Downloads ထဲ သိမ်းနေတယ်…"
        Thread {
            try {
                val mp3Name = saveBytesToDownloads(
                    audio, "zhang-studio-voice-${stamp()}.mp3", "audio/mpeg"
                )
                val srtName = ttsLastSrt?.let { saveSrtToDownloads(it) }
                runOnUiThread {
                    ttsDownloadButton.isEnabled = true
                    if (mp3Name != null) {
                        ttsStatusText.text = "ပြီးပြီ — Downloads ထဲ သိမ်းပြီးပြီ:\n$mp3Name" +
                            (if (srtName != null) "\n$srtName" else "")
                    } else {
                        ttsStatusText.text = "အမှား: အသံဖိုင် သိမ်းလို့ မရဘူး။"
                    }
                }
            } catch (e: Exception) {
                runOnUiThread {
                    ttsDownloadButton.isEnabled = true
                    ttsStatusText.text = "အမှား: ${e.message ?: "unknown error"}"
                }
            }
        }.start()
    }

    private fun onTimingDownloadClicked() {
        val output = timingLastOutput ?: return
        timingDownloadButton.isEnabled = false
        timingStatusText.text = "Downloads ထဲ သိမ်းနေတယ်…"
        Thread {
            try {
                val savedName = copyToDownloads(output, "video/mp4")
                runOnUiThread {
                    timingDownloadButton.isEnabled = true
                    if (savedName != null) {
                        timingStatusText.text =
                            "ပြီးပြီ — Downloads ထဲ သိမ်းပြီးပြီ:\n$savedName"
                    } else {
                        timingStatusText.text = "အမှား: သိမ်းလို့ မရဘူး။"
                    }
                }
            } catch (e: Exception) {
                runOnUiThread {
                    timingDownloadButton.isEnabled = true
                    timingStatusText.text = "အမှား: ${e.message ?: "unknown error"}"
                }
            }
        }.start()
    }

    // Download the last finished video without re-running the job:
    // the cached file is copied to Downloads (no data used), or the
    // video is fetched again from the saved server URL if the cache is gone.
    private fun onVoDownloadClicked() {
        val tmp = voLastTmp
        val videoUrl = voLastVideoUrl
        if (tmp == null || videoUrl == null) return
        voDownloadButton.isEnabled = false
        voStatusText.text = "Video ဒေါင်းလုဒ်လုပ်နေတယ်…"
        Thread {
            try {
                val file = if (tmp.exists()) {
                    tmp
                } else {
                    val fresh = File(cacheDir, "voiceover-${stamp()}.mp4")
                    TranscribeClient(contentResolver).downloadToFile(videoUrl, fresh)
                    voLastTmp = fresh
                    fresh
                }
                val savedName = copyToDownloads(file, "video/mp4")
                val srtName = voLastSrt?.takeIf { it.isNotBlank() }
                    ?.let { saveSrtToDownloads(it) }
                runOnUiThread {
                    voDownloadButton.isEnabled = true
                    voStatusText.text = if (savedName != null) {
                        "ပြီးပြီ — Downloads ထဲ သိမ်းပြီးပြီ:\n$savedName" +
                            (if (srtName != null) "\n$srtName" else "")
                    } else {
                        "အမှား: Video သိမ်းလို့ မရဘူး။"
                    }
                }
            } catch (e: Exception) {
                runOnUiThread {
                    voDownloadButton.isEnabled = true
                    voStatusText.text = "အမှား: ${e.message ?: "unknown error"}"
                }
            }
        }.start()
    }

    private fun onPvDownloadClicked() {
        val tmp = pvLastTmp
        val videoUrl = pvLastVideoUrl
        if (tmp == null || videoUrl == null) return
        pvDownloadButton.isEnabled = false
        pvStatusText.text = "Video ဒေါင်းလုဒ်လုပ်နေတယ်…"
        Thread {
            try {
                val file = if (tmp.exists()) {
                    tmp
                } else {
                    val fresh = File(cacheDir, "prompt-video-${stamp()}.mp4")
                    TranscribeClient(contentResolver).downloadToFile(videoUrl, fresh)
                    pvLastTmp = fresh
                    fresh
                }
                val savedName = copyToDownloads(file, "video/mp4")
                val srtName = pvLastSrt?.takeIf { it.isNotBlank() }
                    ?.let { saveSrtToDownloads(it) }
                runOnUiThread {
                    pvDownloadButton.isEnabled = true
                    pvStatusText.text = if (savedName != null) {
                        "ပြီးပြီ — Downloads ထဲ သိမ်းပြီးပြီ:\n$savedName" +
                            (if (srtName != null) "\n$srtName" else "")
                    } else {
                        "အမှား: Video သိမ်းလို့ မရဘူး။"
                    }
                }
            } catch (e: Exception) {
                runOnUiThread {
                    pvDownloadButton.isEnabled = true
                    pvStatusText.text = "အမှား: ${e.message ?: "unknown error"}"
                }
            }
        }.start()
    }

    private fun onTimingBurnClicked() {
        val video = timingVideoUri ?: return
        val cues = SrtParser.shifted(timingCues, timingShiftUs)
        if (cues.isEmpty()) {
            timingStatusText.text = "ရွှေ့ပြီးနောက် စာတန်း မကျန်ဘူး။"
            return
        }
        timingBusy = true
        updateTimingEnabled()
        timingDownloadButton.visibility = View.GONE
        timingLastOutput = null
        timingProgressBar.progress = 0
        timingStatusText.text = "စာတန်းထည့်နေတယ်… 0%"
        try {
            val typeface = loadMyanmarTypeface()
            val outputFile = newOutputFile()
            val newBurner = SubtitleBurner(this)
            timingBurner = newBurner
            newBurner.start(video, cues, typeface, outputFile, timingBurnCallback)
        } catch (e: Exception) {
            timingBusy = false
            updateTimingEnabled()
            timingStatusText.text = "အမှား: ${e.message ?: "unknown error"}"
        }
    }

    private fun onTimingSaveSrtClicked() {
        val cues = SrtParser.shifted(timingCues, timingShiftUs)
        if (cues.isEmpty()) {
            timingStatusText.text = "ရွှေ့ပြီးနောက် စာတန်း မကျန်ဘူး။"
            return
        }
        timingBusy = true
        updateTimingEnabled()
        timingStatusText.text = "SRT သိမ်းနေတယ်…"
        Thread {
            val savedName = saveSrtToDownloads(SrtParser.toSrtText(cues))
            runOnUiThread {
                timingBusy = false
                updateTimingEnabled()
                timingProgressBar.progress = 100
                if (savedName != null) {
                    timingStatusText.text =
                        "ပြီးပြီ — SRT ကို Downloads ထဲ သိမ်းပြီးပြီ:\n$savedName"
                } else {
                    timingStatusText.text = "အမှား: SRT သိမ်းလို့ မရဘူး။"
                }
            }
        }.start()
    }

    private fun updateTimingEnabled() {
        val ready = !timingBusy && timingVideoUri != null && timingCues.isNotEmpty()
        timingBurnButton.isEnabled = ready
        timingSaveSrtButton.isEnabled = ready
        timingPickVideoButton.isEnabled = !timingBusy
        timingPickSrtButton.isEnabled = !timingBusy
    }

    private fun updateTimingInfo() {
        if (timingCues.isEmpty()) {
            timingInfoText.text = ""
            return
        }
        val shifted = SrtParser.shifted(timingCues, timingShiftUs)
        if (shifted.isEmpty()) {
            timingInfoText.text = "ရွှေ့ပြီးနောက် စာတန်း မကျန်ဘူး။"
            return
        }
        timingInfoText.text =
            "စာတန်း ${shifted.size} ပိုင်း — ပထမ စာတန်း ${formatClockUs(shifted.first().startUs)} မှာ စမယ်"
    }

    /** Polls the server until the job finishes (about 10 minutes max). */
    private fun pollUntilDone(
        client: TranscribeClient,
        jobId: String,
        maxWaits: Int = 150
    ): TranscribeClient.JobState {
        var failures = 0
        var waited = 0
        while (waited < maxWaits) {
            val state = try {
                client.poll(jobId)
            } catch (e: IOException) {
                failures++
                if (failures > 5) {
                    throw IOException("Server နဲ့ အဆက်ပြတ်သွားတယ်။ ထပ်စမ်းပါ။")
                }
                null
            }
            if (state != null) {
                failures = 0
                when (state.status) {
                    "done" -> return state
                    "error" -> throw IOException(state.error ?: "Server error")
                    // "pending": keep waiting.
                }
            }
            Thread.sleep(4000)
            waited++
        }
        throw IOException("အချိန်ကြာလွန်းတယ်။ ထပ်စမ်းပါ။")
    }

    private fun waitForJob(client: TranscribeClient, jobId: String): String {
        val state = pollUntilDone(client, jobId)
        return state.srt ?: throw IOException("Server returned no subtitles")
    }

    private fun postStatus(text: String) {
        runOnUiThread { setStatus(text) }
    }

    private fun postError(message: String) {
        runOnUiThread {
            setBusy(false)
            setStatus("အမှား: $message")
        }
    }

    // ---------- helpers ----------

    private fun titleText(text: String, size: Float): TextView = TextView(this).apply {
        this.text = text
        textSize = size
        setTypeface(typeface, Typeface.BOLD)
        setTextColor(Color.WHITE)
        gravity = Gravity.CENTER
    }

    private fun sectionLabel(text: String): TextView = TextView(this).apply {
        this.text = text
        textSize = 17f
        setTypeface(typeface, Typeface.BOLD)
        setTextColor(Color.WHITE)
    }

    private fun hintText(text: String): TextView = TextView(this).apply {
        this.text = text
        textSize = 13f
        setTextColor(Color.rgb(235, 235, 235))
        gravity = Gravity.CENTER
    }

    private fun pillBg(color: Int, strokeColor: Int?, strokeWidthDp: Int): GradientDrawable =
        GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dp(30).toFloat()
            setColor(color)
            if (strokeColor != null) setStroke(dp(strokeWidthDp), strokeColor)
        }

    private fun pillButton(text: String, bg: Int, fg: Int, stroke: Int?): Button =
        Button(this).apply {
            this.text = text
            isAllCaps = false
            textSize = 18f
            setTextColor(fg)
            background = pillBg(bg, stroke, 2)
            setPadding(dp(20), dp(12), dp(20), dp(12))
        }

    private fun rowParams(topDp: Int): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(topDp) }

    /**
     * Bundled Noto Sans Myanmar (shapes Myanmar correctly with
     * StaticLayout). Falls back to the system default typeface if the
     * asset is missing — most Android devices ship a Myanmar font.
     */
    private fun loadMyanmarTypeface(): Typeface {
        return try {
            Typeface.createFromAsset(assets, "NotoSansMyanmar-Regular.ttf")
        } catch (e: Exception) {
            Typeface.DEFAULT
        }
    }

    /**
     * Copies [source] into the public Downloads folder (MediaStore, no
     * storage permission needed for the app's own files on Android 10+).
     * Returns the file name on success, null on failure (or on Android
     * older than 10, where the private path is reported instead). The
     * private temp file is deleted after a successful copy.
     */
    private fun copyToDownloads(source: File, mimeType: String): String? {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return null
        return try {
            val values = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, source.name)
                put(MediaStore.Downloads.MIME_TYPE, mimeType)
                put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
            }
            val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                ?: return null
            contentResolver.openOutputStream(uri)?.use { out ->
                FileInputStream(source).use { it.copyTo(out) }
            } ?: return null
            source.delete()
            source.name
        } catch (e: Exception) {
            null
        }
    }

    /** Writes bytes straight into the public Downloads folder. */
    private fun saveBytesToDownloads(bytes: ByteArray, name: String, mimeType: String): String? {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return null
        return try {
            val values = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, name)
                put(MediaStore.Downloads.MIME_TYPE, mimeType)
                put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
            }
            val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                ?: return null
            contentResolver.openOutputStream(uri)?.use { out ->
                out.write(bytes)
            } ?: return null
            name
        } catch (e: Exception) {
            null
        }
    }

    /** Writes SRT text straight into the public Downloads folder. */
    private fun saveSrtToDownloads(srtText: String): String? {
        return saveBytesToDownloads(
            srtText.toByteArray(Charsets.UTF_8),
            "zhang-studio-${stamp()}.srt",
            "application/x-subrip"
        )
    }

    private fun stamp(): String =
        SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(Date())

    /** Output goes to the app's private Movies folder (no storage permission needed). */
    private fun newOutputFile(): File {
        val dir = getExternalFilesDir(Environment.DIRECTORY_MOVIES) ?: cacheDir
        if (!dir.exists()) dir.mkdirs()
        return File(dir, "zhang-studio-subtitled-${stamp()}.mp4")
    }

    private fun formatClockUs(timeUs: Long): String {
        val totalSeconds = timeUs / 1_000_000L
        val minutes = totalSeconds / 60L
        val seconds = totalSeconds % 60L
        return "%02d:%02d".format(minutes, seconds)
    }

    private fun fmtSeconds(seconds: Double): String {
        return if (seconds == seconds.toInt().toDouble()) {
            seconds.toInt().toString()
        } else {
            "%.1f".format(seconds)
        }
    }

    private fun updateMakeEnabled() {
        makeButton.isEnabled = videoUri != null
    }

    private fun setBusy(busy: Boolean) {
        pickVideoButton.isEnabled = !busy
        makeButton.isEnabled = !busy && videoUri != null
    }

    private fun setStatus(text: String) {
        statusText.text = text
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
